# CI Workflow Summary

Order enforced by .github/workflows/ci.yml (included at ci/ci.yml):

1. Install dependencies
2. TypeScript check (`bunx tsc --noEmit`)
3. Full tests
4. `qa:critical`
5. `qa:manifest:verify`
6. Build (`bun run build`)
7. Required artifact file check
8. Pre-upload artifact validation (schema, sha256, retention, secrets-excluded, release-ready)
9. Retention policy gate (must be exactly 90 days)
10. Upload artifact `erpovo-ci-qa-summary-<sha>` — retained 90 days

Secrets never uploaded: .env, *.pem, *secret*, *token*, *api_key*, node_modules, perf_stress*.
