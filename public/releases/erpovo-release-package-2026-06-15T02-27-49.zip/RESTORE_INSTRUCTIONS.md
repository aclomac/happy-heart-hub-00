# Restore Instructions

## 1. Restore code/build
```bash
unzip erpovo-release-package-*.zip -d erpovo-release
cd erpovo-release
# Option A: serve prebuilt
#   The build/ directory contains the production output (dist/).
# Option B: rebuild from source at the same git commit:
#   git checkout <commit-from-RELEASE_NOTES.md>
#   bun install
#   bun run build
```

## 2. Verify QA manifest
```bash
sha256sum -c qa-summary.sha256
bun run qa:manifest:verify
```
Expected sha256: `6e9d135e5ec97e458f7c0aeb04033d533493bd546a44ec3121bf828f91420589`

## 3. Restore company data (separate step)
Company-scoped data is NOT included. Use the in-app utility:
- App → Utilities → Restore Backup, OR
- `bun run scripts/backup-export.ts --snapshot --company-id=<uuid>`
  (requires SUPABASE_SERVICE_ROLE_KEY in env, never committed).

Disabled money-impacting tables (sales, sale_invoices, sale_orders, purchases,
purchase_invoices, purchase_orders, stock_movements, payments, payments_in,
payments_out) are stripped at the restore layer even if present in a backup.

## 4. Re-attach integration credentials
WooCommerce and Steadfast credentials are NOT in this package. Re-enter them in:
- App → Ecommerce → Settings (WooCommerce)
- App → Ecommerce → Courier (Steadfast)
