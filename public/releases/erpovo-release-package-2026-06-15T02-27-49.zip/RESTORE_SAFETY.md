# Restore Safety Test Summary

- Module: `src/lib/restore-safety.ts`
- Tests file: `src/test/unit/restore-safety.test.ts`
- Result: 21 passed / 0 failed

## Disabled tables (stripped on restore)
- sales
- sale_invoices
- sale_orders
- purchases
- purchase_invoices
- purchase_orders
- stock_movements
- payments
- payments_in
- payments_out

## Forbidden payload patterns (stripped on restore)
- `perf_stress`
- `.env`
- `secret`
- `auth_token`
- `api_key`
- `password`
- `token`

## Checklist gates (UI)
- valid_file_uploaded
- manifest_parsed
- company_scope_matched
- dry_run_completed
- conflicts_reviewed
- mode_selected
- money_tables_excluded
- confirmation_checked
- typed_RESTORE

UI route: `/app/utilities/restore-backup`
