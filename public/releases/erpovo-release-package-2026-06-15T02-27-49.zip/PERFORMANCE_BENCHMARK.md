# 500,000-Record Cached Performance Benchmark

Preserved and untouched in this release.

- Location: App → Utilities → Performance Test
- Behavior: cached benchmark over 500,000 records; uses IndexedDB stress dataset
- The PERF stress dataset itself is intentionally EXCLUDED from all backup
  and release packaging (forbidden pattern `perf_stress*`).
- Benchmark logic is covered by qa:critical (performance file group).
