# ERPOVO Final Release Checklist

- [x] QA passed (TypeScript 0 errors, tests 1332/1335, qa:critical 128/128)
- [x] Hash verified (sha256 6e9d135e5ec97e458f7c0aeb04033d533493bd546a44ec3121bf828f91420589)
- [x] Backup created (this package)
- [x] Restore workflow ready (see RESTORE_INSTRUCTIONS.md)
- [ ] Company data snapshot — handled separately via `bun run scripts/backup-export.ts --snapshot --company-id=<uuid>`
- [ ] WooCommerce / Steadfast credentials — stored separately (NOT in this package)
- [x] Ready to publish

## Excluded from package
- .env / .env.* (all secrets)
- API keys, auth tokens, payment secrets
- node_modules
- PERF stress data
